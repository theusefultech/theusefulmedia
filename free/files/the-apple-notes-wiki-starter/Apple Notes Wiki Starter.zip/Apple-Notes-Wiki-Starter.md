# Home

Your wiki starts here. Pin this note and everything else stays one tap away.

Replace the bracketed lines below with links to your own notes. To make a link, type two greater-than signs, then start typing a note title.

---

## Writing

- [Link to your ideas note]
- [Link to your drafts note]
- [Link to your published log]

## Work

- [Link to your current project]
- [Link to your meeting notes]
- [Link to your someday list]

## Reading

- [Link to your book notes]
- [Link to your highlights]
- [Link to your to-read list]

## Life

- [Link to your household note]
- [Link to your travel note]
- [Link to your health note]

## Reference

- [Link to your logins and account note]
- [Link to your recipes]
- [Link to your gift ideas]

---

## Tags I use

Keep this list short. Nine is plenty. Type a hash followed by one unbroken word, then a space.

#draft #book-notes #project #reference #idea #someday #waiting #receipt #recipe

---

## How this works

Four things run this system. Each takes under a minute to learn.

### Links between notes

Type two greater-than signs anywhere in a note. A list of your notes appears. Pick one. The link text always matches that note's current title, so renaming the note updates every link pointing at it.

### Links to a section

Select some text. Open the menu, tap the right arrow, then Add Link. Leave the note field empty and tap Link to Section. Pick a heading. Turn on Use section title if you want the link text to match the heading.

Sections have to be real headings. Use the AA button and set Heading or Subheading. Bold text will not work.

### A table of contents

In any long note, put your cursor under the title and repeat the section-link step once per heading. You now have a clickable contents block and you will never scroll that note again.

### Dividers

Place the cursor, tap it, tap the right arrow, choose Insert Divider Line. Use them between the sections of a long note so you can see the structure at a glance.

---

## Your first fifteen minutes

1. Rename this note Home and pin it.
2. Pick five notes you open most and link them under the headings above.
3. Delete any heading you do not need. Five sections is the ceiling.
4. Add the Notes widget to your home screen so Home is one tap away.
5. Tag three existing notes, then make a Smart Folder for one of those tags.

---

## What this does not do

Apple Notes has no backlinks. If this note links to another, that note has no idea. There is no graph view and no way to see the shape of your own thinking from above.

The workaround is manual. At the bottom of your most-referenced notes, keep a short Referenced in list and add the link by hand. Four seconds each time, and it covers most of what a backlink panel gives you.

If you are building a thousand-note Zettelkasten, this is not enough and you should stay where you are. If you have two hundred notes and mostly want to find things, it is more than enough.

---

Built by Raja at The Useful Tech.
